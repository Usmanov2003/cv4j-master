package com.cv4j.app.app

import androidx.appcompat.app.AppCompatActivity

/**
 *
 * @FileName:
 *          com.cv4j.app.app.BaseActivity
 * @author: Tony Shen
 * @date: 2020-05-04 10:50
 * @version: V1.0 <描述当前版本功能>
 */
open class BaseActivity : AppCompatActivity() {
    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
    }
}